import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar as CalendarIcon, Clock, ChevronLeft, ChevronRight, Check, Loader2, Video, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format, addDays, startOfWeek, isSameDay, addWeeks, subWeeks, setHours, setMinutes, isBefore, isToday } from 'date-fns';
import { base44 } from '@/api/base44Client';

const generateTimeSlots = (date) => {
  const slots = [];
  const startHour = 9;
  const endHour = 17;
  const day = date.getDay();
  const now = new Date();
  
  if (day === 0 || day === 6) return [];
  
  for (let hour = startHour; hour < endHour; hour++) {
    [0, 30].forEach(minute => {
      const slotTime = setMinutes(setHours(date, hour), minute);
      // Only include future time slots
      if (!isBefore(slotTime, now)) {
        slots.push({
          time: slotTime,
          label: format(slotTime, 'h:mm a')
        });
      }
    });
  }
  
  return slots;
};

const visitTypes = [
  { value: 'virtual', label: 'Virtual Consultation', icon: Video },
  { value: 'in_person', label: 'In-Person Visit', icon: MapPin }
];

export default function InChatCalendar({ onBooking, userName, userEmail }) {
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [visitType, setVisitType] = useState('virtual');
  const [availableSlots, setAvailableSlots] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeek, i));
  const today = new Date();

  const handleDateSelect = async (day) => {
    const now = new Date();
    const isPast = isBefore(day, now) && !isToday(day);
    const isWeekend = day.getDay() === 0 || day.getDay() === 6;
    
    if (isPast || isWeekend) return;
    
    setSelectedDate(day);
    setSelectedSlot(null);
    setIsLoading(true);
    
    try {
      const allSlots = generateTimeSlots(day);
      const slotsWithAvailability = await Promise.all(
        allSlots.map(async (slot) => {
          const dateStr = format(day, 'yyyy-MM-dd');
          const [hours, minutes] = slot.label.split(':');
          const startTime = `${hours.padStart(2, '0')}:${minutes.split(' ')[0]}`;
          const endHour = parseInt(hours) + 1;
          const endTime = `${endHour.toString().padStart(2, '0')}:${minutes.split(' ')[0]}`;
          
          try {
            const { data } = await base44.functions.invoke('calendarAvailability', {
              date: dateStr,
              startTime,
              endTime,
              visitType
            });
            return { ...slot, available: data.available };
          } catch {
            return { ...slot, available: false };
          }
        })
      );
      setAvailableSlots(slotsWithAvailability);
    } catch (error) {
      console.error('Availability check failed:', error);
      setAvailableSlots([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSlotSelect = (slot) => {
    if (!slot.available) {
      const alternatives = availableSlots.filter(s => s.available).slice(0, 2);
      onBooking({
        type: 'unavailable',
        requested: { date: selectedDate, slot },
        alternatives: alternatives.length > 0 ? alternatives : []
      });
      // Refresh slots to show current availability
      handleDateSelect(selectedDate);
      return;
    }
    
    setSelectedSlot(slot);
  };

  const handleConfirmBooking = async () => {
    if (!selectedDate || !selectedSlot) return;
    
    setIsLoading(true);
    
    try {
      // Race condition protection: recheck availability before booking
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      const [hours, minutes] = selectedSlot.label.split(':');
      const startTime = `${hours.padStart(2, '0')}:${minutes.split(' ')[0]}`;
      const endHour = parseInt(hours) + 1;
      const endTime = `${endHour.toString().padStart(2, '0')}:${minutes.split(' ')[0]}`;
      
      const { data: availCheck } = await base44.functions.invoke('calendarAvailability', {
        date: dateStr,
        startTime,
        endTime,
        visitType
      });
      
      if (!availCheck.available) {
        setIsLoading(false);
        onBooking({
          type: 'unavailable',
          requested: { date: selectedDate, slot: selectedSlot },
          alternatives: availableSlots.filter(s => s.available).slice(0, 2)
        });
        // Refresh slots
        handleDateSelect(selectedDate);
        return;
      }
      
      const { data } = await base44.functions.invoke('bookAppointment', {
        name: userName || 'Guest',
        email: userEmail,
        date: dateStr,
        time: selectedSlot.label,
        procedure: 'Initial Consultation',
        consultationType: visitType === 'virtual' ? 'Virtual' : 'In-Person',
        visitType
      });
      
      if (data.status === 'booked') {
        // Immediately mark slot as unavailable in current state
        setAvailableSlots(prev => 
          prev.map(s => 
            s.label === selectedSlot.label 
              ? { ...s, available: false } 
              : s
          )
        );
        
        onBooking({
          type: 'confirmed',
          date: selectedDate,
          slot: selectedSlot,
          userName,
          visitType,
          eventId: data.eventId
        });
      }
    } catch (error) {
      console.error('Booking failed:', error);
      onBooking({
        type: 'error',
        message: 'Booking failed. Please try again or contact support.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl border border-[#E8E3DC] p-4 my-3"
    >
      <div className="flex items-center gap-2 mb-4">
        <CalendarIcon className="w-4 h-4 text-[#4A1515]" />
        <h4 className="text-sm font-medium text-[#2D0A0A]">Select Your Consultation Time</h4>
      </div>

      {/* Visit Type Selection */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {visitTypes.map((type) => {
          const Icon = type.icon;
          return (
            <button
              key={type.value}
              onClick={() => {
                setVisitType(type.value);
                setSelectedSlot(null);
                if (selectedDate) {
                  handleDateSelect(selectedDate);
                }
              }}
              className={`flex items-center justify-center gap-2 p-2.5 rounded-lg border text-xs font-medium transition-all ${
                visitType === type.value
                  ? 'bg-gradient-to-br from-[#3D1010] to-[#4A1515] text-white border-[#4A1515]'
                  : 'bg-white text-[#4A3628] border-[#E8E3DC] hover:border-[#C4A484]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {type.label}
            </button>
          );
        })}
      </div>

      {/* Week Navigation */}
      <div className="flex items-center justify-between mb-3">
        <button
          onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}
          className="p-1.5 rounded-lg hover:bg-[#F0EBE5] text-[#4A3628] transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="text-xs font-medium text-[#2D0A0A]">
          {format(currentWeek, 'MMMM yyyy')}
        </span>
        <button
          onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}
          className="p-1.5 rounded-lg hover:bg-[#F0EBE5] text-[#4A3628] transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Days */}
      <div className="grid grid-cols-7 gap-1 mb-4">
        {weekDays.map((day, index) => {
            const now = new Date();
            const dayIsToday = isToday(day);
            const isPast = isBefore(day, now) && !dayIsToday;
            const isSelected = selectedDate && isSameDay(day, selectedDate);
            const isWeekend = index === 5 || index === 6;
          
          return (
            <button
              key={index}
              onClick={() => handleDateSelect(day)}
              disabled={isPast || isWeekend}
              className={`p-1.5 rounded-lg text-center transition-all text-xs ${
                isSelected
                  ? 'bg-gradient-to-br from-[#3D1010] to-[#4A1515] text-white'
                  : isPast || isWeekend
                  ? 'text-[#C4B8A8] cursor-not-allowed opacity-50'
                  : dayIsToday
                  ? 'bg-[#FBF8F5] text-[#4A1515] border border-[#4A1515]'
                  : 'hover:bg-[#F0EBE5] text-[#4A3628]'
              }`}
            >
              <span className="block text-[9px] uppercase">
                {format(day, 'EEE')}
              </span>
              <span className="block text-sm font-medium">
                {format(day, 'd')}
              </span>
            </button>
          );
        })}
      </div>

      {/* Time Slots */}
      {isLoading && selectedDate && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-5 h-5 text-[#4A1515] animate-spin" />
        </div>
      )}

      {!isLoading && selectedDate && availableSlots.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 mb-2">
            <Clock className="w-3 h-3 text-[#4A1515]" />
            <span className="text-xs font-medium text-[#2D0A0A]">
              {format(selectedDate, 'EEEE, MMMM d')}
            </span>
          </div>
          
          <div className="grid grid-cols-3 gap-1.5 max-h-32 overflow-y-auto mb-3">
            {availableSlots.slice(0, 12).map((slot, idx) => (
              <button
                key={idx}
                onClick={() => slot.available && handleSlotSelect(slot)}
                disabled={!slot.available}
                className={`p-2 rounded-lg border text-xs transition-all ${
                  selectedSlot?.label === slot.label
                    ? 'border-[#4A1515] bg-[#FBF8F5] text-[#4A1515] font-medium'
                    : slot.available
                    ? 'border-[#E8E3DC] hover:border-[#C4A484] bg-white text-[#4A3628]'
                    : 'border-[#F0EBE5] bg-[#F5F5F5] text-[#C4B8A8] cursor-not-allowed opacity-60 line-through'
                }`}
              >
                {slot.label}
              </button>
            ))}
          </div>

          {selectedSlot && (
            <Button
              onClick={handleConfirmBooking}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#3D1010] to-[#4A1515] hover:from-[#4A1515] hover:to-[#5A2020] text-white rounded-lg h-9 text-sm disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                  Booking...
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-1" />
                  Confirm {selectedSlot.label}
                </>
              )}
            </Button>
          )}
        </div>
      )}

      {selectedDate && availableSlots.length === 0 && (
        <p className="text-xs text-[#8B7355] text-center py-4">
          No availability on weekends. Please select a weekday.
        </p>
      )}

      {!selectedDate && (
        <p className="text-xs text-[#8B7355] text-center py-3">
          Select a date to view available times
        </p>
      )}

      <p className="text-[10px] text-[#8B7355] text-center mt-3">
        All times shown in Pacific Time (PT)
      </p>
    </motion.div>
  );
}