import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Video, 
  MapPin, 
  CheckCircle,
  CalendarDays,
  Sparkles,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format, addDays, startOfWeek, isSameDay, addWeeks, subWeeks } from 'date-fns';
import { base44 } from '@/api/base44Client';

const consultationTypes = [
  { id: 'virtual', label: 'Virtual Consultation', icon: Video, description: 'Video call from anywhere' },
  { id: 'inperson', label: 'In-Person Visit', icon: MapPin, description: 'Beverly Hills office' },
];

const generateTimeSlots = () => {
  const slots = [];
  const times = ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'];
  times.forEach(time => {
    slots.push({ time, available: false }); // Default to unavailable until checked
  });
  return slots;
};

export default function CalendarView() {
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedType, setSelectedType] = useState('virtual');
  const [isBooked, setIsBooked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [timeSlots, setTimeSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeek, i));
  const today = new Date();

  const loadAvailability = async (date, visitType) => {
    setLoadingSlots(true);
    setTimeSlots([]);
    
    try {
      const allSlots = generateTimeSlots();
      const dateStr = format(date, 'yyyy-MM-dd');
      
      const slotsWithAvailability = await Promise.all(
        allSlots.map(async (slot) => {
          const [timeStr, period] = slot.time.split(' ');
          let [hours, minutes] = timeStr.split(':').map(Number);
          if (period === 'PM' && hours !== 12) hours += 12;
          if (period === 'AM' && hours === 12) hours = 0;
          
          const startTime = `${String(hours).padStart(2, '0')}:${String(minutes || 0).padStart(2, '0')}`;
          const endHour = hours + 1;
          const endTime = `${String(endHour).padStart(2, '0')}:${String(minutes || 0).padStart(2, '0')}`;
          
          try {
            const { data } = await base44.functions.invoke('calendarAvailability', {
              date: dateStr,
              startTime,
              endTime,
              visitType
            });
            return { ...slot, available: data.available };
          } catch {
            return { ...slot, available: false };
          }
        })
      );
      
      setTimeSlots(slotsWithAvailability);
    } catch (error) {
      console.error('Failed to load availability:', error);
      setTimeSlots(generateTimeSlots());
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setSelectedTime(null);
    loadAvailability(date, selectedType);
  };

  const handleTypeChange = (type) => {
    setSelectedType(type);
    setSelectedTime(null);
    if (selectedDate) {
      loadAvailability(selectedDate, type);
    }
  };

  const handleBook = async () => {
    if (!selectedDate || !selectedTime) return;
    
    setIsLoading(true);
    
    try {
      const user = await base44.auth.me();
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      
      const { data } = await base44.functions.invoke('bookAppointment', {
        name: user?.full_name || 'Guest',
        email: user?.email,
        date: dateStr,
        time: selectedTime,
        procedure: 'Initial Consultation',
        consultationType: selectedType === 'virtual' ? 'Virtual' : 'In-Person',
        visitType: selectedType
      });
      
      if (data.status === 'booked') {
        setIsBooked(true);
      }
    } catch (error) {
      console.error('Booking failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isBooked) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-[#FDFCFB]">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 15 }}
          className="w-20 h-20 rounded-full bg-gradient-to-br from-[#3D1010] to-[#4A1515] flex items-center justify-center mb-6"
        >
          <CheckCircle className="w-10 h-10 text-white" />
        </motion.div>
        <motion.h3
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-xl font-medium text-[#2D0A0A] mb-3 text-center"
        >
          Consultation Scheduled
        </motion.h3>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mb-6"
        >
          <p className="text-[#4A1515] font-medium">
            {selectedDate && format(selectedDate, 'EEEE, MMMM d, yyyy')}
          </p>
          <p className="text-[#6B5C4C]">
            {selectedTime} • {selectedType === 'virtual' ? 'Virtual' : 'In-Person'}
          </p>
        </motion.div>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-[#6B5C4C] text-center text-sm max-w-xs mb-8"
        >
          You'll receive a confirmation email shortly with details and preparation instructions.
        </motion.p>
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          onClick={() => {
            setIsBooked(false);
            setSelectedDate(null);
            setSelectedTime(null);
            setIsLoading(false);
            // Reset to current week to force fresh availability
            setCurrentWeek(startOfWeek(new Date(), { weekStartsOn: 1 }));
          }}
          className="text-[#4A1515] text-sm font-medium hover:underline"
        >
          Schedule another appointment
        </motion.button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#FDFCFB]">
      {/* Consultation Type */}
      <div className="px-4 py-4 border-b border-[#F0EBE5] bg-white">
        <div className="flex gap-2">
          {consultationTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => handleTypeChange(type.id)}
              className={`flex-1 p-3 rounded-xl border-2 transition-all ${
                selectedType === type.id
                  ? 'border-[#4A1515] bg-[#FBF8F5]'
                  : 'border-[#E8E3DC] bg-white hover:border-[#C4A484]'
              }`}
            >
              <type.icon className={`w-5 h-5 mx-auto mb-2 ${
                selectedType === type.id ? 'text-[#4A1515]' : 'text-[#8B7355]'
              }`} />
              <p className={`text-xs font-medium ${
                selectedType === type.id ? 'text-[#4A1515]' : 'text-[#4A3628]'
              }`}>
                {type.label}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Calendar */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-4">
          {/* Week Navigation */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setCurrentWeek(subWeeks(currentWeek, 1))}
              className="p-2 rounded-lg hover:bg-[#F0EBE5] text-[#4A3628] transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h3 className="text-sm font-medium text-[#2D0A0A]">
              {format(currentWeek, 'MMMM yyyy')}
            </h3>
            <button
              onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}
              className="p-2 rounded-lg hover:bg-[#F0EBE5] text-[#4A3628] transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Days */}
          <div className="grid grid-cols-7 gap-1 mb-6">
            {weekDays.map((day, index) => {
              const isToday = isSameDay(day, today);
              const isPast = day < today && !isToday;
              const isSelected = selectedDate && isSameDay(day, selectedDate);
              const isWeekend = index === 5 || index === 6;
              
              return (
                <button
                  key={index}
                  onClick={() => !isPast && !isWeekend && handleDateSelect(day)}
                  disabled={isPast || isWeekend}
                  className={`p-2 rounded-xl text-center transition-all ${
                    isSelected
                      ? 'bg-gradient-to-br from-[#3D1010] to-[#4A1515] text-white'
                      : isPast || isWeekend
                      ? 'text-[#C4B8A8] cursor-not-allowed'
                      : isToday
                      ? 'bg-[#FBF8F5] text-[#4A1515] border border-[#4A1515]'
                      : 'hover:bg-[#F0EBE5] text-[#4A3628]'
                  }`}
                >
                  <span className="text-[10px] uppercase tracking-wide">
                    {format(day, 'EEE')}
                  </span>
                  <span className="block text-lg font-medium mt-0.5">
                    {format(day, 'd')}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Time Slots */}
          <AnimatePresence mode="wait">
            {selectedDate && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <CalendarDays className="w-4 h-4 text-[#4A1515]" />
                  <h4 className="text-sm font-medium text-[#2D0A0A]">
                    {format(selectedDate, 'EEEE, MMMM d')}
                  </h4>
                </div>

                {loadingSlots ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 text-[#4A1515] animate-spin" />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {timeSlots.map((slot, index) => (
                      <button
                        key={index}
                        onClick={() => slot.available && setSelectedTime(slot.time)}
                        disabled={!slot.available}
                        className={`p-3 rounded-xl border-2 transition-all flex items-center gap-2 ${
                          selectedTime === slot.time
                            ? 'border-[#4A1515] bg-[#FBF8F5]'
                            : slot.available
                            ? 'border-[#E8E3DC] hover:border-[#C4A484] bg-white'
                            : 'border-[#F0EBE5] bg-[#F5F5F5] cursor-not-allowed opacity-60'
                        }`}
                      >
                        <Clock className={`w-4 h-4 ${
                          selectedTime === slot.time
                            ? 'text-[#4A1515]'
                            : slot.available
                            ? 'text-[#8B7355]'
                            : 'text-[#C4B8A8]'
                        }`} />
                        <span className={`text-sm ${
                          selectedTime === slot.time
                            ? 'text-[#4A1515] font-medium'
                            : slot.available
                            ? 'text-[#4A3628]'
                            : 'text-[#C4B8A8] line-through'
                        }`}>
                          {slot.time}
                        </span>
                        {!slot.available && (
                          <span className="text-[10px] text-[#C4B8A8] ml-auto">Booked</span>
                        )}
                        {slot.available && selectedTime !== slot.time && (
                          <Sparkles className="w-3 h-3 text-[#C4A484] ml-auto" />
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {!selectedDate && (
            <div className="text-center py-8">
              <CalendarDays className="w-10 h-10 text-[#C4B8A8] mx-auto mb-3" />
              <p className="text-[#8B7355] text-sm">
                Select a date to view available times
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="px-4 py-4 border-t border-[#F0EBE5] bg-white">
        <Button
          onClick={handleBook}
          disabled={!selectedDate || !selectedTime || isLoading}
          className="w-full bg-gradient-to-r from-[#3D1010] to-[#4A1515] hover:from-[#4A1515] hover:to-[#5A2020] text-white rounded-xl h-12 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Booking...
            </>
          ) : selectedDate && selectedTime ? (
            <span>Confirm {selectedTime} Appointment</span>
          ) : (
            <span>Select Date & Time</span>
          )}
        </Button>
        <p className="text-center text-xs text-[#8B7355] mt-3">
          Free consultation • No obligation
        </p>
      </div>
    </div>
  );
}