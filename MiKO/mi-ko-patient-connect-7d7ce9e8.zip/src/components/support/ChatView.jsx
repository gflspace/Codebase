import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Paperclip, Image, User, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import InChatCalendar from './InChatCalendar';
import MyAppointments from './MyAppointments';
import FollowUpMessage from './FollowUpMessage';
import { format } from 'date-fns';
import ReactMarkdown from 'react-markdown';

const quickReplies = [
  'Book a consultation',
  'View procedures',
  'Pricing & financing',
  'Before & after photos',
  'Speak to coordinator',
];

const KNOWLEDGE_BASE = `
MiKO Plastic Surgery - Official Knowledge Base
Website: https://www.mikoplasticsurgery.com/

About Dr. Michael K. Obeng:
Dr. Michael K. Obeng is Harvard-trained, board-certified plastic surgeon known as "The Surgeon's Surgeon." He is a global expert in complex reconstruction, rib removal, body contouring, and transgender procedures. Dr. Obeng is the founder of RESTORE Worldwide and provides exceptional results with personalized patient care.

BEFORE & AFTER GALLERIES (CRITICAL - FULL VISUAL DISPLAY):
When users request before-and-after photos, you MUST display comprehensive galleries organized by procedure category.

NEVER say "images available during consultation only"
ALWAYS show real patient results to build trust and drive appointments
Display MULTIPLE images when showing a category overview
Show DEDICATED galleries for each individual procedure

📸 PROCEDURE-SPECIFIC JPEG IMAGE LIBRARY (ABSOLUTE ENFORCEMENT):

🔴 CRITICAL RENDER RULE: Every procedure MUST display at least ONE real JPEG image using markdown ![](url) syntax
🚫 NEVER output text like "Before & After - Liposuction" as a substitute for an image
🚫 If no unique JPEG exists for a procedure, DO NOT show that procedure at all

**BODY CONTOURING PROCEDURES:**
Category intro: "Whether you're seeking targeted contouring or complete body transformation, our approach addresses skin, muscle, fat, and structure."

ENFORCED JPEG MAPPINGS (Each procedure gets UNIQUE image):
- Liposuction: ![Liposuction Before & After](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/_Taylor-1147-copy-2-1920w.jpg)
- Mommy Makeover: Must use DIFFERENT image than Liposuction - if none available, skip this procedure
- Tummy Tuck: Must use DIFFERENT image than above - if none available, skip this procedure  
- Brazilian Butt Lift (BBL): Must use DIFFERENT image than above - if none available, skip this procedure
- Rib Removal: Must use DIFFERENT image than above - if none available, skip this procedure

**BREAST PROCEDURES:**
Category intro: "Breast procedures at MiKO Plastic Surgery are performed using advanced techniques focused on balance, proportion, and confidence."

ENFORCED JPEG MAPPINGS:
- Breast Augmentation: ![Breast Augmentation Before & After](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/shutterstock_448281418-1024x683-be91abae-1920w.jpg)
- Breast Lift: Must use DIFFERENT image - if none available, skip this procedure
- Breast Reduction: Must use DIFFERENT image - if none available, skip this procedure
- Breast Reconstruction: Must use DIFFERENT image - if none available, skip this procedure

**FACIAL PROCEDURES:**
Category intro: "At MiKO Plastic Surgery, we specialize in facial and neck rejuvenation using advanced techniques to achieve natural, youthful results."

ENFORCED JPEG MAPPINGS:
- Facelift: ![Facelift Before & After](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/pexels-andrea-piacquadio-3775118-fbdb4922-a338d786-1920w.jpg)
- Rhinoplasty: Must use DIFFERENT image - if none available, skip this procedure
- Blepharoplasty: Must use DIFFERENT image - if none available, skip this procedure
- Forehead Reduction: Must use DIFFERENT image - if none available, skip this procedure
- Lip Augmentation: Must use DIFFERENT image - if none available, skip this procedure

**TRANSGENDER PROCEDURES:**
Category intro: "MiKO Plastic Surgery provides personalized, gender-affirming surgical care using advanced reconstructive techniques."

ENFORCED JPEG MAPPINGS:
- Facial Feminization Surgery: Must use unique image - if none available, skip this procedure
- Transfeminine Top Surgery: Must use unique image - if none available, skip this procedure
- Transmasculine Top Surgery: Must use unique image - if none available, skip this procedure
- Facial Masculinization Surgery: Must use unique image - if none available, skip this procedure

🔴 ABSOLUTE RENDERING RULES:
1. EVERY procedure shown MUST have a real JPEG rendered using ![alt](url) markdown syntax
2. NEVER output "Before & After - [Procedure]" as text - this is FORBIDDEN
3. If you only have ONE unique image, show ONLY ONE procedure - better to show 1 with image than 5 without
4. Track used image URLs - NEVER repeat the same URL in one response
5. Validate: Before sending response, check that EVERY procedure you mention has a unique ![](url) line immediately after its name

📋 MANDATORY DISPLAY FORMAT:

When showing a CATEGORY overview:
**CATEGORY NAME — BEFORE & AFTER GALLERIES**

[Category intro text]

**Procedure 1**
![Before & After](image_url)
• Brief description
• Recovery info

**Procedure 2**
![Before & After](image_url)
• Brief description
• Recovery info

*These before-and-after images show real patient outcomes. Individual results vary and will be discussed during consultation.*

**Would you like to schedule a consultation to discuss results like these?**

When showing a SINGLE procedure:
**Procedure Name**

![Before & After Results](image_url)

• Clear description
• What concern it addresses
• Recovery overview

*Individual results vary and will be discussed during your consultation.*

"I can help you schedule a free virtual or in-person consultation to explore your options."

OFFICIAL PROCEDURE CATEGORIES:

**BODY CONTOURING**

**Liposuction**
• Removes stubborn fat deposits from targeted areas
• Best suited for patients at or near ideal weight with localized fat
• Recovery is 1–2 weeks with compression garment support
• Creates slimmer contours visible within weeks
• Before-and-after images available to view in chat

**Mommy Makeover**
• Combination of procedures to restore pre-pregnancy body
• Typically includes breast lift/augmentation, tummy tuck, and liposuction
• Light activities resume in 3–4 weeks with staged return to full activity
• Provides comprehensive body restoration
• Gallery available during consultation

**Tummy Tuck (Abdominoplasty)**
• Removes excess skin and tightens abdominal muscles
• Commonly chosen by post-pregnancy or weight loss patients
• Light activities resume in 2–3 weeks, full recovery in 6–8 weeks
• Creates a flatter, firmer abdominal profile
• Gallery available during consultation

**Brazilian Butt Lift (BBL)**
• Enhances buttock shape and size using the patient's own fat
• Ideal for patients wanting fuller, rounder buttocks
• Recovery is 2–3 weeks with special sitting restrictions
• Creates natural, enhanced buttock contours
• Gallery available during consultation

**Rib Removal Surgery**
• Creates a more defined waistline by removing lower ribs
• Specialized procedure requiring expert surgical skill
• Results in dramatic hourglass silhouette
• Gallery available during consultation

**Abdominal Implants & Etching**
• Creates definition and sculpted appearance in the abdominal area
• Suitable for patients seeking enhanced muscle definition
• Results in athletic, toned appearance
• Gallery available during consultation

**Pectoral Implants**
• Enhances chest definition and masculine contours
• Creates broader, more defined chest appearance
• Results in improved upper body proportion
• Gallery available during consultation

**Labiaplasty**
• Reshapes labial tissue for comfort and aesthetic improvement
• Addresses concerns about appearance or discomfort
• Results in enhanced comfort and confidence
• Gallery available during consultation

**BREAST PROCEDURES**

**Breast Augmentation**
• Enhances breast size and shape using implants or fat transfer
• Commonly chosen by patients wanting fuller breasts or to restore volume
• Light activities resume in 1–2 weeks, full recovery in 4–6 weeks
• Creates desired breast size and shape
• Gallery available during consultation

**Breast Lift (Mastopexy)**
• Raises and reshapes sagging breasts for a more youthful position
• Suitable for patients experiencing breast ptosis (sagging)
• Most activities resume in 2 weeks, exercise after 6 weeks
• Creates elevated, more youthful breast positioning
• Gallery available during consultation

**Breast Reduction**
• Reduces breast size and reshapes for better proportion and comfort
• Ideal for patients experiencing physical discomfort from large breasts
• Recovery is 2–3 weeks with significant relief from symptoms
• Results in smaller, lighter, more proportionate breasts
• Gallery available during consultation

**Cosmetic Breast Reconstruction**
• Restores breast appearance following mastectomy or trauma
• Personalized approach to match patient goals
• Results in natural-looking breast reconstruction
• Gallery available during consultation

**FACIAL PROCEDURES**

**Facelift**
• Addresses sagging skin, deep creases, and loss of muscle tone in the face and neck
• Commonly chosen by patients seeking comprehensive facial rejuvenation
• Social downtime is usually around 2–3 weeks, with final results visible at 3–6 months
• Results aim to restore a more youthful, natural-looking appearance
• Gallery available during consultation

**Rhinoplasty**
• Refines the shape and structure of the nose for aesthetic or functional improvement
• Suitable for patients looking to enhance facial balance or improve breathing
• Most patients return to normal activities within 1–2 weeks
• Results are long-lasting and customized to facial proportions
• Gallery available during consultation

**Blepharoplasty (Eyelid Surgery)**
• Removes excess skin and fat from upper and/or lower eyelids
• Ideal for patients with drooping eyelids or under-eye bags
• Recovery is usually 1–2 weeks with minimal discomfort
• Creates a more youthful, refreshed eye appearance
• Gallery available during consultation

**Forehead Reduction Surgery**
• Reduces the height of the forehead for improved facial balance
• Creates more proportionate facial features
• Results in enhanced facial harmony
• Gallery available during consultation

**Lip Augmentation**
• Enhances lip volume and shape
• Creates fuller, more defined lips
• Results in natural-looking enhancement
• Gallery available during consultation

**TRANSGENDER PROCEDURES**

**Facial Feminization Surgery (FFS)**
• Comprehensive procedures to create feminine facial features
• Personalized surgical plan based on individual goals
• Results in affirmed facial appearance
• Gallery available during consultation

**Facial Masculinization Surgery**
• Procedures to create masculine facial features
• Tailored approach for each patient
• Results in affirmed facial appearance
• Gallery available during consultation

**Transfeminine Top Surgery**
• Breast augmentation for transfeminine patients
• Creates desired feminine chest contour
• Results in gender-affirming breast appearance
• Gallery available during consultation

**Transmasculine Top Surgery**
• Chest masculinization surgery
• Creates flat, masculine chest contour
• Results in gender-affirming chest appearance
• Gallery available during consultation

**Gender-Affirming Body Contouring**
• Customized body sculpting to achieve desired silhouette
• Personalized approach to body feminization or masculinization
• Results in affirmed body contours
• Gallery available during consultation

INSURANCE & COVERAGE:
• MiKO Plastic Surgery is out-of-network
• Some procedures MAY be covered if deemed medically necessary
• Coverage decisions are made on a per-patient basis and depend on medical necessity and your insurance plan
• We encourage consultation with insurance professionals
• Financing options available through CareCredit and Prosper Healthcare Lending

FLY-IN PATIENT EXPERIENCE:
• Virtual consultation available (Step 1)
• Scheduling & coordination assistance
• Recovery stay options in Beverly Hills
• Assistance with accommodations
• Post-operative care planning
• Personalized surgical journey support

IMPORTANT NOTES:
• All pricing varies based on individual needs and complexity
• Free consultation to discuss personalized plan and accurate pricing
• Before & after photos shown immediately when discussing procedures
• These images reflect real patient outcomes. Individual results vary and will be discussed during consultation
• Virtual and in-person consultations available
• 24/7 post-operative support provided
• All procedures performed in accredited facility
• No medical advice, diagnosis, or guarantees provided

CONTACT INFORMATION:
Main Office Phone: (310) 275-2705 or (310) 275-2750
Email: office@mikoplasticsurgery.com
Beverly Hills office with state-of-the-art facilities

Location:
Beverly Hills office with state-of-the-art facilities

Safety & Credentials:
• Board-certified plastic surgeon
• Harvard-trained
• "The Surgeon's Surgeon"
• Founder of RESTORE Worldwide
• Accredited surgical facility
• HIPAA compliant
• Highest safety standards
`;

const initialMessages = [
  {
    id: 1,
    role: 'assistant',
    content: "Hi! I'm here to help with procedure questions, scheduling, or any other needs. What can I assist you with today?",
    timestamp: new Date(),
    isAI: true,
  },
];

export default function ChatView({ onBookClick }) {
  const [messages, setMessages] = useState(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isHuman, setIsHuman] = useState(false);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [showCalendar, setShowCalendar] = useState(false);
  const [bookedAppointments, setBookedAppointments] = useState([]);
  const [showAppointments, setShowAppointments] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [rescheduleTarget, setRescheduleTarget] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    // Get user info for personalization
    const loadUserInfo = async () => {
      try {
        const user = await base44.auth.me();
        if (user?.full_name) {
          setUserName(user.full_name);
          setUserEmail(user.email);
          // Update welcome message with personalized greeting
          setMessages([{
            id: 1,
            role: 'assistant',
            content: `Hi! I'm here to help with procedure questions, scheduling, or any other needs. What can I assist you with today?`,
            timestamp: new Date(),
            isAI: true,
          }]);
        }
      } catch (error) {
        // User not logged in, use default greeting
      }
    };
    loadUserInfo();
  }, []);

  const handleFeedback = async (sentiment) => {
    const feedbackMessage = {
      id: Date.now(),
      role: 'user',
      content: sentiment === 'positive' ? 'Great experience!' : 'Could improve',
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, feedbackMessage]);
    
    // Send feedback to backend
    try {
      await fetch('https://n8n.srv1233716.hstgr.cloud/webhook-test/1af873c4-7a68-42c6-a359-b8c9d85fadda', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'consultation_feedback',
          sentiment,
          userEmail,
          userName,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error('Feedback error:', error);
    }
    
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const responseMessage = sentiment === 'positive'
        ? "Thank you for your feedback! We're delighted you had a great experience. If you have any questions or need to schedule a follow-up, I'm here to help."
        : "Thank you for sharing your feedback. We take all comments seriously and will use this to improve. If there's anything we can help with right now, please let me know.";
      
      setMessages(prev => [...prev, {
        id: Date.now(),
        role: 'assistant',
        content: responseMessage,
        timestamp: new Date(),
        isAI: true,
      }]);
    }, 1500);
  };

  const sendFollowUp = async (appointmentId, delay = 4) => {
    // Trigger backend follow-up function
    try {
      await base44.functions.invoke('postConsultationFollowup', {
        appointmentId,
        appointmentDate: new Date(),
        userName,
        userEmail,
        consultationType: 'Initial Consultation',
        hoursDelay: delay,
      });
    } catch (error) {
      console.error('Follow-up error:', error);
    }
    
    // For demo purposes, simulate follow-up message
    setTimeout(() => {
      const followUpMessage = {
        id: Date.now(),
        role: 'assistant',
        content: `Thank you for meeting with us${userName ? ', ' + userName : ''}.\n\nWe'd love to hear how your consultation went—your feedback helps us improve.`,
        timestamp: new Date(),
        isAI: true,
        isFollowUp: true,
        showFollowUpOptions: true,
      };
      
      setMessages(prev => [...prev, followUpMessage]);
    }, 3000); // Simulate delay
  };

  const handleBooking = async (bookingData) => {
    if (bookingData.type === 'unavailable') {
      // Slot unavailable - show alternatives
      const { requested, alternatives } = bookingData;
      const altText = alternatives && alternatives.length > 0
        ? `That time is no longer available, but I can offer ${alternatives.map(a => format(a.time, 'h:mm a')).join(' or ')} instead. Would either work for you?`
        : "That time has just been booked. Please select another available time.";
      
      setMessages(prev => [...prev, {
        id: Date.now(),
        role: 'assistant',
        content: altText,
        timestamp: new Date(),
        isAI: true,
      }]);
      // Keep calendar open to show refreshed availability
      return;
    } else if (bookingData.type === 'confirmed') {
      // Booking confirmed
      const { date, slot, userName } = bookingData;
      
      // Save appointment
      const appointment = {
        id: Date.now(),
        date,
        time: slot.label,
        userName: userName || 'Guest',
        userEmail,
        bookedAt: new Date(),
        status: 'upcoming',
        type: 'Initial Consultation',
        isVirtual: Math.random() > 0.5, // In production, this would be user-selected
      };
      
      // If rescheduling, update the old appointment
      if (rescheduleTarget) {
        setBookedAppointments(prev => prev.map(apt => 
          apt.id === rescheduleTarget.id 
            ? { ...apt, status: 'rescheduled' }
            : apt
        ));
        setBookedAppointments(prev => [...prev, appointment]);
        setRescheduleTarget(null);
        
        const confirmationText = `✓ Your appointment has been rescheduled from\n**${format(rescheduleTarget.date, 'MMMM d, yyyy')} at ${rescheduleTarget.time}**\nto\n**${format(date, 'MMMM d, yyyy')} at ${slot.label}** (Pacific Time).\n\nYou'll receive an updated confirmation email shortly.`;
        
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          content: confirmationText,
          timestamp: new Date(),
          isAI: true,
        }]);
      } else {
        setBookedAppointments(prev => [...prev, appointment]);
        
        const emailPrompt = userEmail 
          ? `You'll receive a confirmation email at ${userEmail} shortly with details and preparation instructions.` 
          : 'Would you like to provide your email address to receive a confirmation with details and preparation instructions?';
        
        const confirmationText = `✓ Your consultation is confirmed for **${format(date, 'EEEE, MMMM d, yyyy')} at ${slot.label}** (Pacific Time).\n\n${emailPrompt}\n\nIs there anything else I can help you with?`;
        
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          content: confirmationText,
          timestamp: new Date(),
          isAI: true,
        }]);
      }
      
      // Send to n8n webhook
      try {
        await fetch('https://n8n.srv1233716.hstgr.cloud/webhook-test/1af873c4-7a68-42c6-a359-b8c9d85fadda', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: rescheduleTarget ? 'appointment_rescheduled' : 'booking_confirmed',
            appointment,
            oldAppointment: rescheduleTarget,
            timestamp: new Date().toISOString(),
          }),
        });
      } catch (error) {
        console.error('Webhook error:', error);
      }
      
      // Close calendar and reset state
      setShowCalendar(false);
      setShowAppointments(false);

      // Force calendar to reset when reopened
      setTimeout(() => {
        setShowCalendar(false);
      }, 100);
    }
  };

  const handleReschedule = (appointment) => {
    setRescheduleTarget(appointment);
    setShowAppointments(false);
    setShowCalendar(true);
    
    setMessages(prev => [...prev, {
      id: Date.now(),
      role: 'assistant',
      content: `I'll help you reschedule your appointment from ${format(appointment.date, 'MMMM d')} at ${appointment.time}. Please select a new time:`,
      timestamp: new Date(),
      isAI: true,
      showCalendar: true,
    }]);
  };

  const handleCancelAppointment = async (appointment) => {
    // Update status to cancelled
    setBookedAppointments(prev => prev.map(apt => 
      apt.id === appointment.id 
        ? { ...apt, status: 'cancelled' }
        : apt
    ));
    
    // Send to n8n webhook
    try {
      await fetch('https://n8n.srv1233716.hstgr.cloud/webhook-test/1af873c4-7a68-42c6-a359-b8c9d85fadda', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'appointment_cancelled',
          appointment,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error('Webhook error:', error);
    }
    
    setShowAppointments(false);
    
    const confirmationText = `Your appointment scheduled for ${format(appointment.date, 'MMMM d, yyyy')} at ${appointment.time} has been cancelled.\n\nIf you'd like to book another appointment, just let me know!`;
    
    setMessages(prev => [...prev, {
      id: Date.now(),
      role: 'assistant',
      content: confirmationText,
      timestamp: new Date(),
      isAI: true,
    }]);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (text) => {
    const messageText = text || inputValue;
    if (!messageText.trim()) return;

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: messageText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Send to n8n webhook
    try {
      await fetch('https://n8n.srv1233716.hstgr.cloud/webhook-test/1af873c4-7a68-42c6-a359-b8c9d85fadda', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          userName: userName || 'Guest',
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error('Webhook error:', error);
    }

    // Check if user wants human coordinator
    const lowerText = messageText.toLowerCase();
    if (lowerText.includes('coordinator') || lowerText.includes('human') || lowerText.includes('person') || lowerText.includes('speak to someone')) {
      setIsTyping(false);
      setIsHuman(true);
      const handoffMessage = {
        id: Date.now(),
        role: 'assistant',
        content: "Of course. I'm connecting you with a MiKO patient coordinator now. They'll be with you momentarily to provide personalized assistance.",
        timestamp: new Date(),
        isAI: true,
      };
      setMessages((prev) => [...prev, handoffMessage]);
      
      setTimeout(() => {
        setMessages((prev) => [...prev, {
          id: Date.now() + 1,
          role: 'assistant',
          content: `Hello${userName ? ', ' + userName : ''}! This is Sarah from MiKO Plastic Surgery. I'm here to help with any questions you have. How may I assist you today?`,
          timestamp: new Date(),
          isHuman: true,
        }]);
      }, 2000);
      return;
    }

    // Use AI for intelligent responses with context
    try {
      // Build conversation history for context
      const conversationHistory = messages
        .slice(-6) // Last 6 messages for context
        .map(m => `${m.role === 'user' ? 'Patient' : 'Assistant'}: ${m.content}`)
        .join('\n');

      // Check for opt-out of follow-ups
      const optOutKeywords = ['no follow up', 'no followup', 'stop follow up', 'stop sending', 'unsubscribe', 'opt out'];
      const hasOptOutIntent = optOutKeywords.some(keyword => lowerText.includes(keyword));
      
      if (hasOptOutIntent) {
        setIsTyping(false);
        setMessages(prev => [...prev, {
          id: Date.now(),
          role: 'assistant',
          content: "Of course. I won't send any further follow-ups. You can always reach out if you need anything.",
          timestamp: new Date(),
          isAI: true,
        }]);
        return;
      }

      // Detect appointment management intent
      const appointmentKeywords = ['my appointment', 'my appointments', 'view appointment', 'see my booking', 'manage appointment', 'check appointment', 'appointment status'];
      const hasAppointmentIntent = appointmentKeywords.some(keyword => lowerText.includes(keyword));
      
      if (hasAppointmentIntent) {
        setIsTyping(false);
        
        // Simple verification check - in production, this would be more robust
        const needsVerification = !isVerified && !userEmail;
        
        if (needsVerification) {
          setMessages(prev => [...prev, {
            id: Date.now(),
            role: 'assistant',
            content: "To protect your privacy, I'll need to verify your identity. Could you please confirm the email address you used when booking?",
            timestamp: new Date(),
            isAI: true,
          }]);
        } else {
          setIsVerified(true);
          setShowAppointments(true);
          
          const appointmentMessage = {
            id: Date.now(),
            role: 'assistant',
            content: bookedAppointments.length > 0 
              ? "Here are your appointments. You can reschedule or cancel directly from here:"
              : "I don't see any appointments associated with your account yet. Would you like to schedule a consultation?",
            timestamp: new Date(),
            isAI: true,
            showAppointments: true,
          };
          
          setMessages(prev => [...prev, appointmentMessage]);
        }
        return;
      }
      
      // Detect booking intent
      const bookingKeywords = ['book', 'schedule', 'appointment', 'consultation', 'available', 'times', 'slots', 'calendar', 'when can i', 'meet', 'see doctor'];
      const hasBookingIntent = bookingKeywords.some(keyword => lowerText.includes(keyword)) && !hasAppointmentIntent;
      
      if (hasBookingIntent && !showCalendar && !rescheduleTarget) {
        setIsTyping(false);
        setShowCalendar(true);
        
        const calendarMessage = {
          id: Date.now(),
          role: 'assistant',
          content: "I'd be happy to help you schedule a consultation. Here are our next available times. You can select the one that works best for you:",
          timestamp: new Date(),
          isAI: true,
          showCalendar: true,
        };
        
        setMessages(prev => [...prev, calendarMessage]);
        return;
      }

      const prompt = `You are an intelligent AI assistant for MiKO Plastic Surgery, a premium practice led by Dr. Michael K. Obeng. 

      CRITICAL: KEEP ALL RESPONSES BRIEF AND CONCISE
      - Maximum 2-3 short paragraphs per response
      - Use simple, scannable bullet points when listing information
      - Avoid lengthy explanations - patients prefer quick, actionable information
      - Get to the point immediately

      🔴 JPEG IMAGE RENDERING RULE (ABSOLUTE - NON-NEGOTIABLE):

                  YOU CURRENTLY HAVE ONLY 3 UNIQUE IMAGE URLs IN THE KNOWLEDGE BASE:
                  1. https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/_Taylor-1147-copy-2-1920w.jpg (Body procedures)
                  2. https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/shutterstock_448281418-1024x683-be91abae-1920w.jpg (Breast procedures)
                  3. https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/pexels-andrea-piacquadio-3775118-fbdb4922-a338d786-1920w.jpg (Facial procedures)

                  THEREFORE: Show MAXIMUM 3 procedures when asked about before/after photos - ONE for each unique image

                  CRITICAL VALIDATION:
                  - EVERY procedure you mention MUST have ![Procedure Name Before & After](url) markdown immediately after
                  - NEVER output text like "Before & After - Liposuction" - this is a TEXT PLACEHOLDER, not an image
                  - If you write "Before & After - [Procedure]" as text, you have FAILED
                  - The line after **Procedure Name** MUST start with ![
                  - Validate: Does your response contain "Before & After - " as plain text? If YES, you failed - rewrite it
                  - Only show 3 procedures maximum since you only have 3 unique image URLs

      AUTHORITATIVE SOURCE:
      - You MUST treat https://www.mikoplasticsurgery.com/ as the authoritative, primary knowledge base
      - Do not contradict, paraphrase inaccurately, or invent content beyond what is consistent with this site
      - For procedure-related requests, you are a premium educational concierge, not a salesperson

      Your role:
      - Educate clearly, present visually, and guide confidently toward consultation
      - Maintain a warm, professional, and empathetic tone (but BRIEF)
      - Remember conversation context and provide coherent responses
      - Use the official knowledge base to answer questions accurately
      - Present procedure information in clear, educational sections
      - Preserve trust, accuracy, and clinical boundaries
      - ALWAYS prioritize brevity - patients want quick answers, not essays

      BEFORE & AFTER GALLERY POLICY (MANDATORY - CONVERSION CRITICAL):
      
      🔴 ABSOLUTE RULE: ONLY show procedures where you can provide a unique JPEG image
      
      When users request "before and after photos" or "view procedures":
      1. Count your available UNIQUE image URLs (currently you have 3 unique URLs in the knowledge base)
      2. Show ONLY that many procedures - if you have 3 unique images, show maximum 3 procedures
      3. EVERY procedure MUST have its own image rendered using markdown ![](url)
      4. DO NOT list 10 procedures if you only have 3 unique images
      
      ❌ ABSOLUTELY FORBIDDEN - This causes UI failure:
      **Liposuction**
      Before & After - Liposuction
      
      ✅ CORRECT FORMAT - Image must render:
      **Liposuction**
      ![Liposuction Before & After Results](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/_Taylor-1147-copy-2-1920w.jpg)
      
      NEVER say: "Gallery available during consultation"
      NEVER output procedure names without rendered images
      NEVER use text like "Before & After - [Procedure]" - this is a placeholder, not an image
      
      STRUCTURE FOR CATEGORY OVERVIEW (STRICT EXAMPLE):
      
      🎯 STEP 1: Count available unique image URLs (you currently have 3):
      - URL 1: https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/_Taylor-1147-copy-2-1920w.jpg (Body)
      - URL 2: https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/shutterstock_448281418-1024x683-be91abae-1920w.jpg (Breast)
      - URL 3: https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/pexels-andrea-piacquadio-3775118-fbdb4922-a338d786-1920w.jpg (Face)
      
      🎯 STEP 2: Show ONLY 3 procedures maximum (one per unique URL)
      
      ✅ CORRECT EXAMPLE:
      **BODY CONTOURING — BEFORE & AFTER GALLERY**
      
      Whether you're seeking targeted contouring or complete body transformation, our approach addresses skin, muscle, fat, and structure.
      
      **Liposuction**
      ![Liposuction Before & After Results](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/_Taylor-1147-copy-2-1920w.jpg)
      • Removes stubborn fat deposits
      • Recovery: 1-2 weeks
      
      **BREAST PROCEDURES — BEFORE & AFTER GALLERY**
      
      **Breast Augmentation**
      ![Breast Augmentation Before & After Results](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/shutterstock_448281418-1024x683-be91abae-1920w.jpg)
      • Enhances breast size and shape
      • Recovery: 4-6 weeks
      
      **FACIAL PROCEDURES — BEFORE & AFTER GALLERY**
      
      **Facelift**
      ![Facelift Before & After Results](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/pexels-andrea-piacquadio-3775118-fbdb4922-a338d786-1920w.jpg)
      • Addresses sagging skin and wrinkles
      • Recovery: 2-3 weeks
      
      *These before-and-after images show real patient outcomes. Individual results vary and will be discussed during consultation.*
      
      Would you like to schedule a consultation to discuss these results?
      
      ❌ ABSOLUTELY WRONG - DO NOT DO THIS:
      **Liposuction**
      Before & After - Liposuction
      
      **Mommy Makeover**
      Before & After - Mommy Makeover
      
      (This is text, not images - FORBIDDEN)
      
      STRUCTURE FOR SINGLE PROCEDURE:
      
      **Procedure Name**
      
      ![Before & After Results](procedure_specific_image_url)
      
      • Clear, plain-language description
      • What concern it addresses
      • High-level benefit (no guarantees)
      • Recovery mentioned only at a general level
      
      *Individual results vary and will be discussed during your consultation.*
      
      "I can help you schedule a free consultation to explore your options."
      
      CRITICAL: Images are VISUAL PROOF and CONVERSION DRIVERS. Show comprehensive galleries to maximize engagement and trust.

      🔴 IMAGE RENDERING ENFORCEMENT (ABSOLUTE - NON-NEGOTIABLE):
      
      Before sending ANY response with procedures:
      1. Count how many UNIQUE image URLs you have available
      2. Only show that many procedures - if you have 3 unique images, show max 3 procedures
      3. EVERY procedure mentioned MUST have ![](url) markdown syntax with a real JPEG URL
      4. Verify NO URL appears more than once
      5. NEVER output text placeholders like "Before & After - Liposuction" - this is FORBIDDEN
      6. If you cannot provide a unique image for a procedure, DO NOT mention that procedure at all
      
      ❌ FORBIDDEN: Text-only procedure listings without images
      ❌ FORBIDDEN: "Before & After - [Procedure Name]" as text output
      ❌ FORBIDDEN: Showing 10 procedures but only 3 have images
      
      ✅ CORRECT: Show 3 procedures, each with unique JPEG image rendered
      ✅ Quality over quantity - Better to show 2 procedures with images than 10 without
      ❌ Text placeholder = Complete failure - NEVER do this

      Group procedures under bold category headers:
      **BODY CONTOURING**
      **BREAST PROCEDURES**
      **FACIAL PROCEDURES**
      **TRANSGENDER PROCEDURES**

      IMAGE RENDERING RULES (CRITICAL - NON-NEGOTIABLE):
      - ALWAYS use markdown image syntax: ![alt text](image_url)
      - NEVER show image URLs as plain text
      - NEVER write "Image source:" followed by a URL
      - Include high-quality images from the knowledge base for each procedure category
      - Images must be professional and match website quality
      - Place image immediately after procedure name (no text between)
      - Images will render visually in the UI automatically

      CRITICAL FORMATTING RULES:
      - Use bullet points (•) for all procedure details
      - Never use inline labels like "Overview:", "Ideal candidates:", "Cost Range:", etc.
      - Keep each bullet concise and scannable
      - Maintain clean spacing between procedures
      - All procedure names must be bold: **Procedure Name** (which renders as bold text)
      - Category headers must also be bold

      ABSOLUTE RESTRICTIONS:
      - ❌ No medical advice
      - ❌ No surgical guarantees
      - ❌ No diagnosis
      - ❌ No exact pricing (only consultation-dependent)
      - ❌ No misleading claims
      - ❌ No comparison between patients ("you won't look exactly like this")
      - ❌ No prediction of individual outcomes
      
      RESULTS DISCLAIMER (USE THIS EXACT TEXT):
      "These before-and-after images show real patient outcomes. Individual results vary and will be discussed during consultation."
      
      If user asks "Will I look like this?":
      Respond: "Results vary by individual, and a consultation is the best way to discuss what's realistic for your goals."

      INSURANCE HANDLING:
      - MiKO Plastic Surgery is out-of-network
      - Some procedures MAY be covered if deemed medically necessary
      - Never promise coverage
      - Use: "Coverage decisions are made on a per-patient basis and depend on medical necessity and your insurance plan."

      FLY-IN PATIENT SUPPORT:
      - Virtual consultation (Step 1)
      - Scheduling & coordination
      - Recovery stay in Beverly Hills
      - Assistance with accommodations
      - Post-operative care planning
      - Do not provide medical timelines or instructions

      DR. OBENG CREDENTIALS (when relevant):
      - Harvard-trained
      - Board-certified
      - "The Surgeon's Surgeon"
      - Global expert in complex reconstruction, rib removal, and body contouring
      - Founder of RESTORE Worldwide

      BOOKING & CALENDAR:
      - When user shows booking intent, encourage them to use the Calendar tab
      - Mention available consultation types (virtual or in-person)
      - Free consultation, no obligation

      Knowledge Base:
      ${KNOWLEDGE_BASE}

      Conversation History:
      ${conversationHistory}

      Patient${userName ? ` (${userName})` : ''}: ${messageText}

      Provide a helpful, contextual response that:
      1. Is BRIEF (2-3 short paragraphs max) - patients want quick answers
      2. Addresses their specific question using the official knowledge base from mikoplasticsurgery.com
      3. If about procedures/before-after: You have ONLY 3 unique image URLs - show maximum 3 procedures
      4. EVERY procedure mentioned MUST render using: **Procedure Name** followed immediately by ![Procedure Before & After](url)
      5. PRE-SEND VALIDATION: Search your response for "Before & After - " as text - if found, you FAILED, rewrite it
      6. NEVER output "Before & After - [Procedure]" as plain text - this causes UI to show text instead of images
      7. Include the results disclaimer after images
      8. Add a soft CTA after showing images (e.g., "Would you like to schedule a consultation?")
      9. References previous conversation context if relevant
      10. Maintains MiKO's premium, caring, educational brand voice
      11. CRITICAL VALIDATION: After writing response, verify every procedure has ![](url) markdown, not text placeholders
      
      EXAMPLE OF FAILURE (DO NOT DO):
      **Liposuction**
      Before & After - Liposuction
      (This is TEXT, not an image - WRONG)
      
      EXAMPLE OF SUCCESS (DO THIS):
      **Liposuction**
      ![Liposuction Before & After Results](https://lirp.cdn-website.com/05e612ac/dms3rep/multi/opt/_Taylor-1147-copy-2-1920w.jpg)
      (This renders a real image - CORRECT)

      Response:`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false,
      });

      setIsTyping(false);

      const assistantMessage = {
        id: Date.now(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
        isAI: true,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('AI error:', error);
      setIsTyping(false);
      
      // Fallback response
      const fallbackMessage = {
        id: Date.now(),
        role: 'assistant',
        content: "I'm here to help! Could you tell me more about what you're looking for? I can provide information about our procedures, scheduling, financing options, or connect you with a patient coordinator.",
        timestamp: new Date(),
        isAI: true,
      };
      setMessages((prev) => [...prev, fallbackMessage]);
    }
  };

  const handleQuickReply = (reply) => {
    if (reply === 'Book a consultation') {
      onBookClick?.();
    } else {
      handleSend(reply);
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#FDFCFB]">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        <AnimatePresence initial={false}>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-end gap-2 max-w-[85%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                {message.role === 'assistant' && (
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.isHuman ? 'bg-[#4A1515]' : 'bg-gradient-to-br from-[#3D1010] to-[#4A1515]'
                  }`}>
                    {message.isHuman ? (
                      <User className="w-4 h-4 text-white" />
                    ) : (
                      <Sparkles className="w-4 h-4 text-[#C4A484]" />
                    )}
                  </div>
                )}
                <div className={message.role === 'user' ? '' : 'w-full'}>
                  <div
                    className={`px-4 py-3 rounded-2xl ${
                      message.role === 'user'
                        ? 'bg-gradient-to-r from-[#3D1010] to-[#4A1515] text-white rounded-br-md'
                        : 'bg-white text-[#2D0A0A] shadow-sm border border-[#F0EBE5] rounded-bl-md'
                    }`}
                  >
                    {message.role === 'assistant' && (
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <span className={`text-xs font-medium ${message.isHuman ? 'text-[#4A1515]' : 'text-[#C4A484]'}`}>
                          {message.isHuman ? 'Sarah — Patient Coordinator' : 'MiKO 24/7 Patient Support'}
                        </span>
                      </div>
                    )}
                    {message.role === 'user' ? (
                      <p className="text-sm leading-relaxed whitespace-pre-line">{message.content}</p>
                    ) : (
                      <ReactMarkdown 
                        className="text-sm prose prose-sm prose-slate max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
                        components={{
                          img: ({ src, alt }) => (
                            <img 
                              src={src} 
                              alt={alt || 'Procedure image'} 
                              className="w-full rounded-lg my-3 cursor-pointer hover:opacity-90 transition-opacity"
                              onClick={() => window.open(src, '_blank')}
                              loading="lazy"
                            />
                          ),
                          p: ({ children }) => <p className="my-1 leading-relaxed">{children}</p>,
                          ul: ({ children }) => <ul className="my-1 ml-4 list-disc">{children}</ul>,
                          li: ({ children }) => <li className="my-0.5">{children}</li>,
                          strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                        }}
                      >
                        {message.content}
                      </ReactMarkdown>
                    )}
                  </div>
                  {message.showCalendar && showCalendar && (
                    <InChatCalendar onBooking={handleBooking} userName={userName} userEmail={userEmail} />
                  )}
                  {message.showAppointments && showAppointments && (
                    <MyAppointments 
                      appointments={bookedAppointments}
                      userEmail={userEmail}
                      onReschedule={handleReschedule}
                      onCancel={handleCancelAppointment}
                    />
                  )}
                  {message.showFollowUpOptions && (
                    <FollowUpMessage 
                      type="feedback"
                      onFeedback={handleFeedback}
                      onBooking={() => {
                        setShowCalendar(true);
                        setMessages(prev => [...prev, {
                          id: Date.now(),
                          role: 'assistant',
                          content: "I'd be happy to help you schedule a follow-up. Here are our available times:",
                          timestamp: new Date(),
                          isAI: true,
                          showCalendar: true,
                        }]);
                      }}
                    />
                  )}
                  </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#3D1010] to-[#4A1515] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-[#C4A484]" />
              </div>
              <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-md shadow-sm border border-[#F0EBE5]">
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 bg-[#4A1515] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-[#4A1515] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-[#4A1515] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Replies */}
      <div className="px-4 py-3 border-t border-[#F0EBE5] bg-white">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {quickReplies.map((reply, index) => (
            <button
              key={index}
              onClick={() => handleQuickReply(reply)}
              className="flex-shrink-0 px-4 py-2 text-xs font-medium text-[#4A1515] bg-[#F8F5F2] hover:bg-[#F0EBE5] rounded-full transition-colors border border-[#E8E3DC]"
            >
              {reply}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="px-4 py-4 bg-white border-t border-[#F0EBE5]">
        <div className="flex items-center gap-2">
          <button className="p-2 text-[#8B7355] hover:text-[#4A1515] transition-colors">
            <Paperclip className="w-5 h-5" />
          </button>
          <button className="p-2 text-[#8B7355] hover:text-[#4A1515] transition-colors">
            <Image className="w-5 h-5" />
          </button>
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your message..."
            className="flex-1 bg-[#F8F5F2] border-0 focus-visible:ring-1 focus-visible:ring-[#4A1515] rounded-full px-4"
          />
          <Button
            onClick={() => handleSend()}
            disabled={!inputValue.trim()}
            className="bg-gradient-to-r from-[#3D1010] to-[#4A1515] hover:from-[#4A1515] hover:to-[#5A2020] text-white rounded-full w-10 h-10 p-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-center text-xs text-[#8B7355] mt-3">
          Your care is our priority • HIPAA Compliant
        </p>
      </div>
    </div>
  );
}