import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, CheckCircle, Mail, Paperclip, X, FileText, Download, Plus, ArrowLeft, Image as ImageIcon, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function EmailView() {
  const [formData, setFormData] = useState({
    subject: '',
    message: '',
    recipient: 'office@mikoplasticsurgery.com',
  });
  const [attachments, setAttachments] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Failed to load user:', error);
      }
    };
    loadUser();
  }, []);

  const sendEmailMutation = useMutation({
    mutationFn: async (emailData) => {
      // Send the actual email first
      await base44.integrations.Core.SendEmail({
        to: emailData.recipient,
        subject: emailData.subject,
        body: emailData.message,
        from_name: user?.full_name || user?.email || 'Patient',
      });
      
      // Then save to database for tracking
      const savedEmail = await base44.entities.EmailMessage.create({
        ...emailData,
        status: 'sent',
      });
      
      return savedEmail;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allEmails'] });
      setFormData({ subject: '', message: '', recipient: 'office@mikoplasticsurgery.com' });
      setAttachments([]);
      setIsSubmitting(false);
    },
    onError: (error) => {
      console.error('Email send error:', error);
      setIsSubmitting(false);
    },
  });

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    setIsSubmitting(true);
    
    const uploadedFiles = await Promise.all(
      files.map(async (file) => {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return {
          name: file.name,
          url: file_url,
          size: file.size,
        };
      })
    );
    
    setAttachments([...attachments, ...uploadedFiles]);
    setIsSubmitting(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    await sendEmailMutation.mutateAsync({
      ...formData,
      attachments,
      status: 'sent',
    });
    
    setIsSubmitting(false);
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const getFileIcon = (fileName) => {
    const ext = fileName.split('.').pop().toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
      return <ImageIcon className="w-4 h-4" />;
    }
    return <File className="w-4 h-4" />;
  };

  return (
    <div className="h-full overflow-y-auto p-6 bg-[#FDFCFB]">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-[#2D0A0A]">Send Message</h3>
        <p className="text-xs text-[#6B5C4C]">Contact MiKO Plastic Surgery</p>
      </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-[#2D0A0A] mb-1.5 block">
              From
            </label>
            <Input
              type="email"
              value={user?.email || ''}
              disabled
              className="bg-[#F0EBE5] border-[#E8E3DC] rounded-xl text-[#6B5C4C]"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-[#2D0A0A] mb-1.5 block">
              To
            </label>
            <Input
              type="email"
              value={formData.recipient}
              onChange={(e) => setFormData({ ...formData, recipient: e.target.value })}
              className="bg-white border-[#E8E3DC] rounded-xl"
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium text-[#2D0A0A] mb-1.5 block">
              Subject
            </label>
            <Input
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              placeholder="What is this regarding?"
              className="bg-white border-[#E8E3DC] rounded-xl"
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium text-[#2D0A0A] mb-1.5 block">
              Message
            </label>
            <Textarea
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Type your message here..."
              className="h-40 bg-white border-[#E8E3DC] rounded-xl resize-none"
              required
            />
          </div>

          {attachments.length > 0 && (
            <div className="space-y-2">
              <label className="text-sm font-medium text-[#2D0A0A] block">
                Attachments ({attachments.length})
              </label>
              <div className="space-y-2">
                {attachments.map((file, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 bg-[#FBF8F5] rounded-lg border border-[#E8E3DC]"
                  >
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      {getFileIcon(file.name)}
                      <span className="text-sm text-[#2D0A0A] truncate">{file.name}</span>
                      <span className="text-xs text-[#8B7355]">
                        ({(file.size / 1024).toFixed(1)} KB)
                      </span>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeAttachment(index)}
                      className="h-6 w-6 p-0"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <label className="flex-1">
              <input
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                disabled={isSubmitting}
              />
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2 border-[#E8E3DC] rounded-xl"
                disabled={isSubmitting}
                onClick={(e) => e.currentTarget.previousElementSibling.click()}
              >
                <Paperclip className="w-4 h-4" />
                Attach Files
              </Button>
            </label>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 bg-gradient-to-r from-[#3D1010] to-[#4A1515] hover:from-[#4A1515] hover:to-[#5A2020] text-white rounded-xl"
            >
              {isSubmitting ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    className="w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"
                  />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send
                </>
              )}
            </Button>
          </div>
        </form>
    </div>
  );
}