import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, MapPin, Video, CheckCircle, XCircle, AlertCircle, Trash2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function MyAppointments({ appointments, userEmail, onReschedule, onCancel }) {
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'upcoming':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-gray-400" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'rescheduled':
        return <AlertCircle className="w-4 h-4 text-blue-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'upcoming':
        return 'Confirmed';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      case 'rescheduled':
        return 'Rescheduled';
      default:
        return status;
    }
  };

  const upcomingAppointments = appointments.filter(apt => 
    apt.status === 'upcoming' || apt.status === 'rescheduled'
  );
  const pastAppointments = appointments.filter(apt => 
    apt.status === 'completed' || apt.status === 'cancelled'
  );

  const handleCancelConfirm = () => {
    if (selectedAppointment) {
      onCancel(selectedAppointment);
      setShowCancelDialog(false);
      setSelectedAppointment(null);
    }
  };

  if (appointments.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl border border-[#E8E3DC] p-6 my-3 text-center"
      >
        <Calendar className="w-12 h-12 text-[#C4B8A8] mx-auto mb-3" />
        <p className="text-sm text-[#6B5C4C] mb-4">
          You don't have any appointments scheduled yet.
        </p>
        <p className="text-xs text-[#8B7355]">
          Would you like to book a consultation?
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl border border-[#E8E3DC] p-4 my-3"
    >
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-4 h-4 text-[#4A1515]" />
        <h4 className="text-sm font-medium text-[#2D0A0A]">My Appointments</h4>
      </div>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <div className="mb-4">
          <h5 className="text-xs font-medium text-[#6B5C4C] mb-2">Upcoming</h5>
          <div className="space-y-2">
            {upcomingAppointments.map((apt, idx) => (
              <div
                key={idx}
                className="border border-[#E8E3DC] rounded-lg p-3 hover:border-[#C4A484] transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {getStatusIcon(apt.status)}
                      <span className="text-xs font-medium text-[#2D0A0A]">
                        {apt.type || 'Consultation'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#6B5C4C] mb-1">
                      <Clock className="w-3 h-3" />
                      <span>{format(apt.date, 'EEEE, MMMM d, yyyy')} at {apt.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#6B5C4C]">
                      {apt.isVirtual ? (
                        <>
                          <Video className="w-3 h-3" />
                          <span>Virtual Consultation</span>
                        </>
                      ) : (
                        <>
                          <MapPin className="w-3 h-3" />
                          <span>Beverly Hills Office</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2 pt-2 border-t border-[#F0EBE5]">
                  <Button
                    onClick={() => onReschedule(apt)}
                    variant="outline"
                    size="sm"
                    className="flex-1 h-8 text-xs"
                  >
                    <RefreshCw className="w-3 h-3 mr-1" />
                    Reschedule
                  </Button>
                  <Button
                    onClick={() => {
                      setSelectedAppointment(apt);
                      setShowCancelDialog(true);
                    }}
                    variant="outline"
                    size="sm"
                    className="flex-1 h-8 text-xs text-red-600 hover:text-red-700 hover:border-red-300"
                  >
                    <Trash2 className="w-3 h-3 mr-1" />
                    Cancel
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Past Appointments */}
      {pastAppointments.length > 0 && (
        <div>
          <h5 className="text-xs font-medium text-[#6B5C4C] mb-2">Past</h5>
          <div className="space-y-2">
            {pastAppointments.map((apt, idx) => (
              <div
                key={idx}
                className="border border-[#F0EBE5] rounded-lg p-3 bg-[#FAFAFA]"
              >
                <div className="flex items-center gap-2 mb-1">
                  {getStatusIcon(apt.status)}
                  <span className="text-xs font-medium text-[#6B5C4C]">
                    {apt.type || 'Consultation'}
                  </span>
                  <span className="text-xs text-[#8B7355] ml-auto">
                    {getStatusText(apt.status)}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-[#8B7355]">
                  <Clock className="w-3 h-3" />
                  <span>{format(apt.date, 'MMM d, yyyy')} at {apt.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <p className="text-[10px] text-[#8B7355] text-center mt-4">
        Need help? Ask me to make changes or book another appointment.
      </p>

      {/* Cancellation Confirmation Dialog */}
      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Appointment</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel your appointment scheduled for{' '}
              {selectedAppointment && format(selectedAppointment.date, 'MMMM d, yyyy')} at{' '}
              {selectedAppointment?.time}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Appointment</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCancelConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              Yes, Cancel Appointment
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
}