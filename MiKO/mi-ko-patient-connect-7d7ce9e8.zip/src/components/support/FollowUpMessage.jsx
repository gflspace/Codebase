import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, ThumbsUp, ThumbsDown, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function FollowUpMessage({ onFeedback, onBooking, type = 'feedback' }) {
  const handleFeedback = (sentiment) => {
    onFeedback?.(sentiment);
  };

  if (type === 'feedback') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#FBF8F5] rounded-xl border border-[#E8E3DC] p-4 my-3"
      >
        <div className="flex items-center gap-2 mb-3">
          <MessageCircle className="w-4 h-4 text-[#4A1515]" />
          <span className="text-xs font-medium text-[#2D0A0A]">How was your consultation?</span>
        </div>
        
        <p className="text-xs text-[#6B5C4C] mb-3">
          Your feedback helps us provide better care.
        </p>
        
        <div className="flex gap-2">
          <Button
            onClick={() => handleFeedback('positive')}
            variant="outline"
            size="sm"
            className="flex-1 h-9 text-xs"
          >
            <ThumbsUp className="w-3 h-3 mr-1" />
            Great Experience
          </Button>
          <Button
            onClick={() => handleFeedback('negative')}
            variant="outline"
            size="sm"
            className="flex-1 h-9 text-xs"
          >
            <ThumbsDown className="w-3 h-3 mr-1" />
            Could Improve
          </Button>
        </div>
      </motion.div>
    );
  }

  if (type === 'booking') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#FBF8F5] rounded-xl border border-[#E8E3DC] p-4 my-3"
      >
        <div className="flex items-center gap-2 mb-3">
          <Calendar className="w-4 h-4 text-[#4A1515]" />
          <span className="text-xs font-medium text-[#2D0A0A]">Ready for your next step?</span>
        </div>
        
        <p className="text-xs text-[#6B5C4C] mb-3">
          I can help you schedule a follow-up appointment whenever you're ready.
        </p>
        
        <Button
          onClick={onBooking}
          className="w-full bg-gradient-to-r from-[#3D1010] to-[#4A1515] hover:from-[#4A1515] hover:to-[#5A2020] text-white rounded-lg h-9 text-xs"
        >
          Schedule Follow-Up
        </Button>
      </motion.div>
    );
  }

  return null;
}