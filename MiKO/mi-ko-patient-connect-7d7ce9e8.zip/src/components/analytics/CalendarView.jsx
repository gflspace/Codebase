import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, ChevronLeft, ChevronRight, Video, MapPin, RefreshCw } from 'lucide-react';
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, addDays, addWeeks, addMonths, subWeeks, subMonths, isSameDay, isToday, isBefore, startOfDay } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';

export default function CalendarView() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [viewMode, setViewMode] = useState('week'); // 'day', 'week', 'month'
  const [currentDate, setCurrentDate] = useState(new Date());
  const [filterType, setFilterType] = useState('all'); // 'all', 'virtual', 'in_person'

  useEffect(() => {
    loadEvents();
  }, [currentDate, viewMode]);

  const loadEvents = async () => {
    setLoading(true);
    try {
      let startDate, endDate;

      if (viewMode === 'day') {
        startDate = new Date(currentDate);
        startDate.setHours(0, 0, 0, 0);
        endDate = new Date(currentDate);
        endDate.setHours(23, 59, 59, 999);
      } else if (viewMode === 'week') {
        startDate = startOfWeek(currentDate, { weekStartsOn: 0 });
        endDate = endOfWeek(currentDate, { weekStartsOn: 0 });
      } else {
        startDate = startOfMonth(currentDate);
        endDate = endOfMonth(currentDate);
      }

      const { data } = await base44.functions.invoke('getCalendarEvents', {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      });

      setEvents(data.events || []);
    } catch (error) {
      console.error('Failed to load events:', error);
      setEvents([]);
    } finally {
      setLoading(false);
    }
  };

  const navigateDate = (direction) => {
    if (viewMode === 'day') {
      setCurrentDate(prev => addDays(prev, direction === 'next' ? 1 : -1));
    } else if (viewMode === 'week') {
      setCurrentDate(prev => direction === 'next' ? addWeeks(prev, 1) : subWeeks(prev, 1));
    } else {
      setCurrentDate(prev => direction === 'next' ? addMonths(prev, 1) : subMonths(prev, 1));
    }
  };

  const getFilteredEvents = () => {
    if (filterType === 'all') return events;
    if (filterType === 'virtual') return events.filter(e => e.visitType === 'virtual');
    if (filterType === 'in_person') return events.filter(e => e.visitType === 'in_person');
    return events;
  };

  const renderDayView = () => {
    const dayEvents = getFilteredEvents().filter(event => {
      const eventDate = new Date(event.start);
      return isSameDay(eventDate, currentDate);
    });

    const hours = Array.from({ length: 10 }, (_, i) => i + 9); // 9 AM to 6 PM

    return (
      <div className="space-y-2">
        {hours.map(hour => {
          const hourEvents = dayEvents.filter(event => {
            const eventHour = new Date(event.start).getHours();
            return eventHour === hour;
          });

          return (
            <div key={hour} className="flex gap-3 border-b border-[#F0EBE5] pb-2">
              <div className="w-20 text-sm text-[#6B5C4C] font-medium pt-1">
                {format(new Date().setHours(hour, 0), 'h:mm a')}
              </div>
              <div className="flex-1 min-h-[60px]">
                {hourEvents.map(event => (
                  <motion.div
                    key={event.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className={`p-3 rounded-lg mb-2 ${
                      event.visitType === 'virtual'
                        ? 'bg-blue-50 border border-blue-200'
                        : 'bg-green-50 border border-green-200'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {event.visitType === 'virtual' ? (
                        <Video className="w-4 h-4 text-blue-600" />
                      ) : (
                        <MapPin className="w-4 h-4 text-green-600" />
                      )}
                      <span className="font-medium text-sm text-[#2D0A0A]">
                        {format(new Date(event.start), 'h:mm a')}
                      </span>
                    </div>
                    <p className="text-sm text-[#4A3628]">{event.summary}</p>
                    <p className="text-xs text-[#6B5C4C] mt-1 capitalize">
                      {event.visitType.replace('_', ' ')}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderWeekView = () => {
    const weekStart = startOfWeek(currentDate, { weekStartsOn: 0 });
    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

    return (
      <div className="grid grid-cols-7 gap-2">
        {weekDays.map(day => {
          const dayEvents = getFilteredEvents().filter(event => {
            const eventDate = new Date(event.start);
            return isSameDay(eventDate, day);
          });

          const isPast = isBefore(day, startOfDay(new Date())) && !isToday(day);

          return (
            <div
              key={day.toISOString()}
              className={`border border-[#E8E3DC] rounded-lg p-3 min-h-[200px] ${
                isToday(day) ? 'bg-[#FBF8F5] border-[#4A1515]' : 'bg-white'
              } ${isPast ? 'opacity-60' : ''}`}
            >
              <div className="text-center mb-3">
                <p className="text-xs text-[#6B5C4C] uppercase">
                  {format(day, 'EEE')}
                </p>
                <p className={`text-lg font-semibold ${
                  isToday(day) ? 'text-[#4A1515]' : 'text-[#2D0A0A]'
                }`}>
                  {format(day, 'd')}
                </p>
              </div>
              <div className="space-y-2">
                {dayEvents.map(event => (
                  <div
                    key={event.id}
                    className={`p-2 rounded text-xs ${
                      event.visitType === 'virtual'
                        ? 'bg-blue-50 border border-blue-200'
                        : 'bg-green-50 border border-green-200'
                    }`}
                  >
                    <div className="flex items-center gap-1 mb-1">
                      {event.visitType === 'virtual' ? (
                        <Video className="w-3 h-3 text-blue-600" />
                      ) : (
                        <MapPin className="w-3 h-3 text-green-600" />
                      )}
                      <span className="font-medium">
                        {format(new Date(event.start), 'h:mm a')}
                      </span>
                    </div>
                    <p className="text-[#4A3628] truncate">{event.summary}</p>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderMonthView = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const startDate = startOfWeek(monthStart, { weekStartsOn: 0 });
    const endDate = endOfWeek(monthEnd, { weekStartsOn: 0 });

    const days = [];
    let day = startDate;

    while (day <= endDate) {
      days.push(day);
      day = addDays(day, 1);
    }

    return (
      <div className="grid grid-cols-7 gap-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-xs font-medium text-[#6B5C4C] mb-2">
            {day}
          </div>
        ))}
        {days.map(day => {
          const dayEvents = getFilteredEvents().filter(event => {
            const eventDate = new Date(event.start);
            return isSameDay(eventDate, day);
          });

          const isCurrentMonth = day.getMonth() === currentDate.getMonth();
          const isPast = isBefore(day, startOfDay(new Date())) && !isToday(day);

          return (
            <div
              key={day.toISOString()}
              className={`border rounded-lg p-2 min-h-[100px] ${
                isToday(day)
                  ? 'bg-[#FBF8F5] border-[#4A1515]'
                  : isCurrentMonth
                  ? 'bg-white border-[#E8E3DC]'
                  : 'bg-[#F5F5F5] border-[#E8E3DC]'
              } ${isPast ? 'opacity-60' : ''}`}
            >
              <p className={`text-sm font-medium mb-1 ${
                isToday(day) ? 'text-[#4A1515]' : isCurrentMonth ? 'text-[#2D0A0A]' : 'text-[#C4B8A8]'
              }`}>
                {format(day, 'd')}
              </p>
              <div className="space-y-1">
                {dayEvents.slice(0, 3).map(event => (
                  <div
                    key={event.id}
                    className={`text-[10px] px-1 py-0.5 rounded truncate ${
                      event.visitType === 'virtual'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-green-100 text-green-700'
                    }`}
                  >
                    {format(new Date(event.start), 'h:mm a')}
                  </div>
                ))}
                {dayEvents.length > 3 && (
                  <p className="text-[10px] text-[#6B5C4C]">+{dayEvents.length - 3} more</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const totalEvents = getFilteredEvents().length;

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigateDate('prev')}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h3 className="text-lg font-semibold text-[#2D0A0A] min-w-[200px] text-center">
            {viewMode === 'day' && format(currentDate, 'EEEE, MMMM d, yyyy')}
            {viewMode === 'week' && `Week of ${format(startOfWeek(currentDate, { weekStartsOn: 0 }), 'MMM d, yyyy')}`}
            {viewMode === 'month' && format(currentDate, 'MMMM yyyy')}
          </h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigateDate('next')}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentDate(new Date())}
          >
            Today
          </Button>
        </div>

        <div className="flex items-center gap-2">
          {/* View Mode */}
          <div className="flex bg-[#F0EBE5] rounded-lg p-1">
            {['day', 'week', 'month'].map(mode => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-3 py-1 text-sm rounded capitalize transition-colors ${
                  viewMode === mode
                    ? 'bg-white text-[#2D0A0A] shadow-sm'
                    : 'text-[#6B5C4C] hover:text-[#2D0A0A]'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          {/* Filter */}
          <div className="flex bg-[#F0EBE5] rounded-lg p-1">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1 text-sm rounded transition-colors ${
                filterType === 'all'
                  ? 'bg-white text-[#2D0A0A] shadow-sm'
                  : 'text-[#6B5C4C] hover:text-[#2D0A0A]'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterType('virtual')}
              className={`px-3 py-1 text-sm rounded transition-colors flex items-center gap-1 ${
                filterType === 'virtual'
                  ? 'bg-white text-[#2D0A0A] shadow-sm'
                  : 'text-[#6B5C4C] hover:text-[#2D0A0A]'
              }`}
            >
              <Video className="w-3 h-3" />
              Virtual
            </button>
            <button
              onClick={() => setFilterType('in_person')}
              className={`px-3 py-1 text-sm rounded transition-colors flex items-center gap-1 ${
                filterType === 'in_person'
                  ? 'bg-white text-[#2D0A0A] shadow-sm'
                  : 'text-[#6B5C4C] hover:text-[#2D0A0A]'
              }`}
            >
              <MapPin className="w-3 h-3" />
              In-Person
            </button>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={loadEvents}
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Event Count */}
      <div className="flex items-center gap-2 text-sm text-[#6B5C4C]">
        <Calendar className="w-4 h-4" />
        <span>
          {totalEvents} {totalEvents === 1 ? 'appointment' : 'appointments'} scheduled
        </span>
      </div>

      {/* Calendar Display */}
      <Card>
        <CardContent className="p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <RefreshCw className="w-8 h-8 text-[#4A1515] animate-spin" />
            </div>
          ) : totalEvents === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-[#C4B8A8] mx-auto mb-3" />
              <p className="text-[#6B5C4C]">No appointments are scheduled for this date.</p>
            </div>
          ) : (
            <>
              {viewMode === 'day' && renderDayView()}
              {viewMode === 'week' && renderWeekView()}
              {viewMode === 'month' && renderMonthView()}
            </>
          )}
        </CardContent>
      </Card>

      {/* Legend */}
      <div className="flex items-center gap-6 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-blue-100 border border-blue-200 rounded" />
          <span className="text-[#6B5C4C]">Virtual Consultation</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-green-100 border border-green-200 rounded" />
          <span className="text-[#6B5C4C]">In-Person Visit</span>
        </div>
      </div>
    </div>
  );
}