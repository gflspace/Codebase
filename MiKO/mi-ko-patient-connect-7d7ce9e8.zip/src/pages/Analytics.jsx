import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, 
  Users, 
  Calendar, 
  Clock, 
  Star, 
  Activity,
  ExternalLink,
  RefreshCw,
  BarChart3,
  Shield,
  Download,
  Mail,
  Send,
  ArrowLeft,
  CalendarDays
} from 'lucide-react';
import CalendarView from '../components/analytics/CalendarView';
import { motion } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

export default function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [systemHealth, setSystemHealth] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [replyMessage, setReplyMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  const queryClient = useQueryClient();

  const { data: emails = [], isLoading: emailsLoading } = useQuery({
    queryKey: ['allEmails'],
    queryFn: () => base44.asServiceRole.entities.EmailMessage.list('-created_date'),
    enabled: isAuthenticated,
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      if (currentUser?.role === 'admin') {
        loadAnalytics();
      } else {
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (password === 'MiKO@Admin') {
      setIsAuthenticated(true);
      setPasswordError('');
      loadAnalytics();
    } else {
      setPasswordError('Incorrect password. Access denied.');
      setPassword('');
    }
  };

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke('getAnalytics');
      setAnalytics(data);
      checkSystemHealth(data);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkSystemHealth = (data) => {
    const health = {
      instantResponse: data?.kpis.avgResponseTime?.includes('sec') || data?.kpis.avgResponseTime?.includes('min'),
      standardizedIntake: data?.kpis.totalLeads > 0,
      selfScheduling: data?.kpis.confirmedBookings > 0,
      automatedReminders: data?.kpis.noShowRate < '20%',
      centralizedVisibility: data?.spreadsheetUrl !== null
    };
    setSystemHealth(health);
  };

  const handleSendReply = async (e) => {
    e.preventDefault();
    setIsSending(true);
    
    try {
      await base44.integrations.Core.SendEmail({
        to: selectedEmail.created_by,
        subject: `Re: ${selectedEmail.subject}`,
        body: replyMessage,
      });
      
      queryClient.invalidateQueries({ queryKey: ['allEmails'] });
      setReplyMessage('');
      setSelectedEmail(null);
    } catch (error) {
      console.error('Failed to send reply:', error);
    } finally {
      setIsSending(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FDFCFB] to-[#F8F5F2] flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 text-[#4A1515] animate-spin mx-auto mb-4" />
          <p className="text-[#6B5C4C]">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FDFCFB] to-[#F8F5F2] flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-[#2D0A0A]">Analytics Dashboard Access</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-[#6B5C4C] mb-6">
              This dashboard provides centralized visibility into lead qualification, scheduling efficiency, and operational metrics.
            </p>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-[#2D0A0A] mb-2 block">
                  Admin Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter admin password"
                  className="w-full px-4 py-2 border border-[#E8E3DC] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4A1515]"
                  autoFocus
                />
              </div>
              {passwordError && (
                <p className="text-sm text-red-600">{passwordError}</p>
              )}
              <Button 
                type="submit"
                className="w-full bg-gradient-to-r from-[#3D1010] to-[#4A1515]"
              >
                Access Dashboard
              </Button>
            </form>
            <Button 
              onClick={() => window.location.href = '/'}
              variant="outline"
              className="w-full mt-3"
            >
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const kpiCards = [
    {
      title: 'Response Speed',
      subtitle: 'Delayed → Instant',
      value: analytics?.kpis.avgResponseTime || 'N/A',
      icon: Clock,
      color: 'from-blue-500 to-blue-600',
      insight: 'Average time from inquiry to first response'
    },
    {
      title: 'Intake Quality',
      subtitle: 'Inconsistent → Standardized',
      value: analytics?.kpis.totalLeads || 0,
      icon: Users,
      color: 'from-purple-500 to-purple-600',
      insight: 'AI-qualified leads with complete intake'
    },
    {
      title: 'Scheduling Efficiency',
      subtitle: 'Manual → Self-Scheduling',
      value: analytics?.kpis.confirmedBookings || 0,
      icon: Calendar,
      color: 'from-green-500 to-green-600',
      insight: 'Successfully booked consultations'
    },
    {
      title: 'No-Show Risk',
      subtitle: 'High → Automated Reminders',
      value: analytics?.kpis.noShowRate || '0%',
      icon: Activity,
      color: 'from-orange-500 to-orange-600',
      insight: 'Automated reminders reducing no-shows'
    },
    {
      title: 'Conversion Rate',
      subtitle: 'Fragmented → Centralized',
      value: analytics?.kpis.conversionRate || '0%',
      icon: TrendingUp,
      color: 'from-indigo-500 to-indigo-600',
      insight: 'Leads converting to consultations'
    },
    {
      title: 'Patient Satisfaction',
      subtitle: 'Measured Feedback',
      value: analytics?.kpis.avgFeedbackScore || 'N/A',
      icon: Star,
      color: 'from-yellow-500 to-yellow-600',
      insight: 'Average post-consultation feedback'
    }
  ];

  if (activeTab === 'calendar') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FDFCFB] to-[#F8F5F2] p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-[#2D0A0A] mb-2">View Calendar</h1>
              <p className="text-[#6B5C4C]">All booked appointment time slots</p>
            </div>
            <Button
              variant="outline"
              onClick={() => setActiveTab('dashboard')}
              className="gap-2"
            >
              <BarChart3 className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </div>

          <CalendarView />
        </div>
      </div>
    );
  }

  if (activeTab === 'emails') {
    if (selectedEmail) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-[#FDFCFB] to-[#F8F5F2] p-6">
          <div className="max-w-4xl mx-auto">
            <Button
              variant="ghost"
              onClick={() => setSelectedEmail(null)}
              className="mb-4 gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Emails
            </Button>

            <Card>
              <CardHeader className="border-b">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl text-[#2D0A0A] mb-2">
                      {selectedEmail.subject}
                    </CardTitle>
                    <div className="text-sm text-[#6B5C4C] space-y-1">
                      <p>From: {selectedEmail.created_by}</p>
                      <p>Date: {format(new Date(selectedEmail.created_date), 'MMM d, yyyy h:mm a')}</p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="mb-6 p-4 bg-[#FBF8F5] rounded-lg">
                  <p className="text-[#2D0A0A] whitespace-pre-wrap">{selectedEmail.message}</p>
                </div>

                {selectedEmail.attachments && selectedEmail.attachments.length > 0 && (
                  <div className="mb-6">
                    <h4 className="text-sm font-medium text-[#2D0A0A] mb-2">
                      Attachments ({selectedEmail.attachments.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedEmail.attachments.map((file, idx) => (
                        <a
                          key={idx}
                          href={file.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 p-2 bg-white border border-[#E8E3DC] rounded-lg hover:border-[#C4A484] transition-colors"
                        >
                          <Download className="w-4 h-4 text-[#4A1515]" />
                          <span className="text-sm text-[#2D0A0A]">{file.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                <form onSubmit={handleSendReply} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-[#2D0A0A] mb-2 block">
                      Reply to {selectedEmail.created_by}
                    </label>
                    <Textarea
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      placeholder="Type your response..."
                      className="h-40 bg-white resize-none"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={isSending}
                    className="bg-gradient-to-r from-[#3D1010] to-[#4A1515] hover:from-[#4A1515] hover:to-[#5A2020] gap-2"
                  >
                    {isSending ? (
                      <>
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                          className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                        />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Send Reply
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FDFCFB] to-[#F8F5F2] p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-[#2D0A0A] mb-2">Patient Emails</h1>
              <p className="text-[#6B5C4C]">View and respond to patient inquiries</p>
            </div>
            <Button
              variant="outline"
              onClick={() => setActiveTab('dashboard')}
              className="gap-2"
            >
              <BarChart3 className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </div>

          {emailsLoading ? (
            <div className="flex items-center justify-center py-12">
              <RefreshCw className="w-8 h-8 text-[#4A1515] animate-spin" />
            </div>
          ) : emails.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Mail className="w-12 h-12 text-[#C4B8A8] mx-auto mb-3" />
                <p className="text-[#6B5C4C]">No patient emails yet</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {emails.map((email) => (
                <motion.div
                  key={email.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="cursor-pointer hover:border-[#C4A484] transition-all"
                    onClick={() => setSelectedEmail(email)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h3 className="font-semibold text-[#2D0A0A] mb-1">
                            {email.subject}
                          </h3>
                          <p className="text-sm text-[#6B5C4C] line-clamp-2 mb-2">
                            {email.message}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-[#8B7355]">
                            <span>From: {email.created_by}</span>
                            <span>{format(new Date(email.created_date), 'MMM d, yyyy')}</span>
                            {email.attachments?.length > 0 && (
                              <span className="flex items-center gap-1">
                                <Download className="w-3 h-3" />
                                {email.attachments.length} file(s)
                              </span>
                            )}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-2"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedEmail(email);
                          }}
                        >
                          <Send className="w-3 h-3" />
                          Reply
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FDFCFB] to-[#F8F5F2] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-[#2D0A0A] mb-2">
                Lead Qualification & Scheduling Analytics
              </h1>
              <p className="text-[#6B5C4C]">
                "We're not automating surgery. We're automating everything that delays it."
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => setActiveTab('emails')}
                variant="outline"
                className="gap-2"
              >
                <Mail className="w-4 h-4" />
                Emails
              </Button>
              <Button
                onClick={() => setActiveTab('calendar')}
                variant="outline"
                className="gap-2"
              >
                <CalendarDays className="w-4 h-4" />
                View Calendar
              </Button>
              <Button
                onClick={loadAnalytics}
                variant="outline"
                className="gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
              <Button
                onClick={async () => {
                  try {
                    const { data } = await base44.functions.invoke('downloadAnalyticsGuide');
                    const blob = new Blob([data], { 
                      type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
                    });
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'Analytics-Dashboard-Guide.docx';
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    a.remove();
                  } catch (error) {
                    console.error('Download error:', error);
                  }
                }}
                variant="outline"
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Download Guide
              </Button>
              {analytics?.spreadsheetUrl && (
                <Button
                  onClick={() => window.open(analytics.spreadsheetUrl, '_blank')}
                  className="bg-gradient-to-r from-[#3D1010] to-[#4A1515] gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  View Sheet
                </Button>
              )}
            </div>
          </div>

          {/* Operational Impact */}
          {analytics && (
            <Card className="bg-gradient-to-r from-[#2D0A0A] to-[#4A1515] text-white">
              <CardHeader className="pb-3">
                <CardTitle className="text-white">Operational Impact — Eliminating Bottlenecks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div>
                    <p className="text-white/70 text-xs mb-1">Automation Coverage</p>
                    <p className="text-2xl font-bold">{analytics?.kpis.automationCoverage || '95%'}</p>
                    <p className="text-white/60 text-xs mt-1">of interactions handled</p>
                  </div>
                  <div>
                    <p className="text-white/70 text-xs mb-1">Staff Hours Saved</p>
                    <p className="text-2xl font-bold">
                      {Math.round((analytics?.kpis.totalLeads || 0) * 0.25)}h
                    </p>
                    <p className="text-white/60 text-xs mt-1">per week</p>
                  </div>
                  <div>
                    <p className="text-white/70 text-xs mb-1">Response Speed</p>
                    <p className="text-2xl font-bold">&lt;30s</p>
                    <p className="text-white/60 text-xs mt-1">average response time</p>
                  </div>
                  <div>
                    <p className="text-white/70 text-xs mb-1">Completed Consultations</p>
                    <p className="text-2xl font-bold">{analytics?.kpis.completedConsultations || analytics?.kpis.confirmedBookings || 0}</p>
                    <p className="text-white/60 text-xs mt-1">successful bookings</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {kpiCards.map((kpi, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <CardTitle className="text-sm font-medium text-[#2D0A0A]">
                        {kpi.title}
                      </CardTitle>
                      <p className="text-xs text-[#8B7355] mt-0.5">{kpi.subtitle}</p>
                    </div>
                    <div className={`p-2 rounded-lg bg-gradient-to-br ${kpi.color}`}>
                      <kpi.icon className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-[#2D0A0A] mb-1">{kpi.value}</p>
                  <p className="text-xs text-[#6B5C4C]">{kpi.insight}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Bookings by Channel */}
        {analytics?.bookingsByChannel && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-[#4A1515]" />
                  <CardTitle className="text-[#2D0A0A]">Bookings by Channel</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(analytics.bookingsByChannel).map(([channel, count]) => (
                    <div key={channel} className="flex items-center justify-between">
                      <span className="text-[#6B5C4C] font-medium">{channel}</span>
                      <div className="flex items-center gap-3">
                        <div className="w-32 h-2 bg-[#F0EBE5] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#3D1010] to-[#4A1515]"
                            style={{
                              width: `${(count / analytics.kpis.totalLeads) * 100}%`
                            }}
                          />
                        </div>
                        <span className="text-[#2D0A0A] font-semibold w-8 text-right">
                          {count}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Automation Impact */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-8"
        >
          <Card className="bg-gradient-to-br from-[#3D1010] to-[#4A1515] text-white">
            <CardHeader>
              <CardTitle>Automation Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-white/70 text-sm mb-2">Coverage</p>
                  <p className="text-3xl font-bold">{analytics?.kpis.automationCoverage || '95%'}</p>
                </div>
                <div>
                  <p className="text-white/70 text-sm mb-2">Completed Consultations</p>
                  <p className="text-3xl font-bold">{analytics?.kpis.completedConsultations || 0}</p>
                </div>
                <div>
                  <p className="text-white/70 text-sm mb-2">Staff Hours Saved</p>
                  <p className="text-3xl font-bold">
                    {Math.round((analytics?.kpis.totalLeads || 0) * 0.25)}h
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {analytics?.lastUpdated && (
          <p className="text-center text-xs text-[#8B7355] mt-6">
            Last updated: {new Date(analytics.lastUpdated).toLocaleString()}
          </p>
        )}
      </div>
    </div>
  );
}