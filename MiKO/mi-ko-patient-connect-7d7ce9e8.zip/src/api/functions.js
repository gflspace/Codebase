import { base44 } from './base44Client';


export const chatWebhook = base44.functions.chatWebhook;

export const postConsultationFollowup = base44.functions.postConsultationFollowup;

export const initializeSheet = base44.functions.initializeSheet;

export const logToSheet = base44.functions.logToSheet;

export const calendarAvailability = base44.functions.calendarAvailability;

export const bookAppointment = base44.functions.bookAppointment;

export const updateAppointment = base44.functions.updateAppointment;

export const cancelAppointment = base44.functions.cancelAppointment;

export const getAnalytics = base44.functions.getAnalytics;

export const downloadAnalyticsGuide = base44.functions.downloadAnalyticsGuide;

export const getCalendarEvents = base44.functions.getCalendarEvents;

